I had written two scripts for this TP, test.py for test the iris.data, test1.py for graphing and complexity.
To execute the programme
commande format for the script test.py in the Theminal:  
		
			python test.py k/'randomk'  'inputdatafile'/randamdata  'randomCentre'/or other     'outputfile'(optional)


Examples:
	python test.py 3 iris.data randomCentre result.data
	python test.py 3 randomdata randomCentre

the script will write a file, 
iris_result.txt : stock the clusters of iris
			 

commande format for the script test1.py:
			
			python test1.py

the script will write three files, 
resultat.txt
out.txt
centre.txt



